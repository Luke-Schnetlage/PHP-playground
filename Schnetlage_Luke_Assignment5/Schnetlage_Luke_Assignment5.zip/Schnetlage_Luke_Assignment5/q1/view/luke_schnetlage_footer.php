<!-- 
Luke Schnetlage
CSCI 4000-10
11/13/22
-->

<footer>
	<p class="right">
		&copy; <?php echo date("Y"); ?> Luke Schnetlage Kung Fu School
	</p>
</footer>
</body>

</html>