<!-- 
Luke Schnetlage
CSCI 4000-10
11/13/22
-->

<!DOCTYPE html>
<html lang="en">

<head>
	<title>Luke Schnetlage Kung Fu School</title>
	<meta charset="utf-8">
	<link href="../main.css" rel="stylesheet" type="text/css">
</head>

<body>
	<header>
		<h1>Luke Schnetlage Kung Fu School</h1>
	</header>