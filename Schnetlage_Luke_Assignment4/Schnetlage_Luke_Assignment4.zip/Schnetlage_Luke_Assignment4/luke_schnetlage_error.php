<!-- 
Luke Schnetlage
CSCI 4000-10
10/30/22
-->
<!DOCTYPE html>
<html lang="en">

<head>
	<title>Luke Schnetlage's kung fu school</title>
	<meta charset="utf-8">
	<link href="main.css" rel="stylesheet" type="text/css">
</head>

<body>
	<header>
		<h1>Luke Schnetlage's kung fu school</h1>
	</header>

	<main>
		<h2>Error</h2>
		<p><?php echo $error; ?></p>
		<br>
		<p><a href="index.php">View All Students</a></p>
	
		<footer>
		<p class="right">
			&copy; <?php echo date("Y"); ?> Luke Schnetlage's kung fu school
		</p>
	</footer>
	</main>

	
</body>

</html>